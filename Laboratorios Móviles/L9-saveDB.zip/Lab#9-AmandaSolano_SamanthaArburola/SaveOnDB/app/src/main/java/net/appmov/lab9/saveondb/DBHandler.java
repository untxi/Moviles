package net.appmov.lab9.saveondb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHandler extends SQLiteOpenHelper {

    private static final int DATA_VERSION = 1;
    private static final String DATA_NAME = "agendaInfo";
    private static final String TABLE_AGENDA = "agenda";

    private static final String KEY_ID    = "id";
    private static final String KEY_NAME  = "name";
    private static final String KEY_PHONE = "phone";
    private static final String KEY_rommnum = "roomNum";
    private static final String KEY_ADRRESS = "address";
    private static final String KEY_LASTNAME = "lastname";
    private static final String KEY_NICKNAME = "nickname";

    public DBHandler (Context context) {
        super (context, DATA_NAME, null, DATA_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_AGENDA_TABLE = "CREATE TABLE " + TABLE_AGENDA + "("
                + KEY_ID + " INTEGER PRIMARY KEY, "+KEY_NAME+" TEXT, "+KEY_PHONE+" INTEGER, "
                +KEY_rommnum+" INTEGER, "+KEY_LASTNAME+" TEXT, "+KEY_NICKNAME+" TEXT, "+KEY_ADRRESS+" TEXT "
                +")";
        db.execSQL(CREATE_AGENDA_TABLE);
    }

    @Override
    public void onUpgrade (SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_AGENDA);
        onCreate(db);
    }

    public void addAgenda(Agenda agenda){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, agenda.getName());
        values.put(KEY_PHONE, agenda.getPhone());
        values.put(KEY_ADRRESS, agenda.getAddress());
        values.put(KEY_LASTNAME, agenda.getLastName());
        values.put(KEY_NICKNAME, agenda.getNickName());
        values.put(KEY_rommnum, agenda.getRoomNum());

        db.insert(TABLE_AGENDA, null, values);
        db.close();
    }

    public Agenda getAgenda(int id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_AGENDA, new String[] {KEY_ID,KEY_NAME,KEY_PHONE, KEY_rommnum, KEY_LASTNAME, KEY_NICKNAME, KEY_ADRRESS}, KEY_ID+"=?",
                new String[] {String.valueOf(id)}, null, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
        }
        Agenda agenda = new Agenda(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1),
                Integer.parseInt(cursor.getString(2)),
                Integer.parseInt(cursor.getString(3)),
                cursor.getString(4),
                cursor.getString(5),
                cursor.getString(6));

        return agenda;
    }

    public List<Agenda> getAllShop(){
        List<Agenda> shopList = new ArrayList<>();

        String selectQuery = "SELECT * FROM "+TABLE_AGENDA;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do{
                Agenda agenda = new Agenda();
                agenda.setId(Integer.parseInt(cursor.getString(0)));
                agenda.setName(cursor.getString(1));
                agenda.setPhone(Integer.parseInt(cursor.getString(2)));
                agenda.setRoomNum(Integer.parseInt(cursor.getString(3)));
                agenda.setLastName(cursor.getString(4));
                agenda.setNickName(cursor.getString(5));
                agenda.setAddress(cursor.getString(6));

                shopList.add(agenda);
            }while(cursor.moveToNext());
        }
        return shopList;
    }

    public int getShopsCount(){
        String countQuery = "SELECT * FROM "+TABLE_AGENDA;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();

        return cursor.getCount();
    }

    public int updateShop(Agenda agenda){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, agenda.getName());
        values.put(KEY_PHONE, agenda.getPhone());
        values.put(KEY_ADRRESS, agenda.getAddress());
        values.put(KEY_NICKNAME, agenda.getRoomNum());
        values.put(KEY_LASTNAME, agenda.getLastName());
        values.put(KEY_rommnum, agenda.getRoomNum());

        return db.update(TABLE_AGENDA, values, KEY_ID+" =? ",
                new String[] {String.valueOf(agenda.getId())});
    }

    public void deleteShop(Agenda agenda){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_AGENDA, KEY_ID+" = ?",
                new String[] {String.valueOf(agenda.getId())});
        db.close();
    }
}
