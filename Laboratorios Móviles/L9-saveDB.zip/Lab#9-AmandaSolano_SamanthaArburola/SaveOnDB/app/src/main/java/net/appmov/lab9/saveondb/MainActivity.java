package net.appmov.lab9.saveondb;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DBHandler db = new DBHandler(this);

        Log.d("Insert: ", "Inserting ..");

        db.addAgenda(new Agenda(1, "Denver", 22345667,2,"Leon","yey", "SJ"));
        db.addAgenda(new Agenda(2, "Milán", 86774444, 2,"Leon","gey", "AL"));
        db.addAgenda(new Agenda(3, "Martin", 66666666,2,"Leon","rey", "HE"));
        db.addAgenda(new Agenda(4, "Roma", 56666733, 2,"Leon","qey", "CA"));
        db.addAgenda(new Agenda(5, "Pepe", 94444442,2,"Leon","ley", "LI"));
        db.addAgenda(new Agenda(6, "Vito", 94440404,2,"Leon","cey", "GU"));

        Log.d("Reading", "Reading all contacts...");
        List<Agenda> agenda = db.getAllShop();

        for (Agenda i : agenda) {
            String log = "Id:" + i.getId() + ",Name: " + i.getName() +", LastName: "+i.getLastName()+", NickName: "+ i.getNickName() +" ,Phone:" + i.getPhone()+", RoomNumer: "+i.getRoomNum()+", Address: "+i.getAddress();
            Log.d("Agenda : :", log);
        }

    }
}