package net.appmov.lab9.saveondb;

/**
 * Created by Donny on 1/9/2016.
 */
public class Agenda{
    private int id;
    private String name;
    private int phone;
    private int roomNum;
    private String address;
    private String lastName;
    private String nickName;

    public Agenda(){}

    public Agenda(int id, String name, int phone, int roomNum, String lastName, String nickName, String address){
        this.id=id;
        this.name=name;
        this.phone=phone;
        this.address = address;
        this.lastName=lastName;
        this.nickName=nickName;
        this.roomNum=roomNum;
    }

    public void   setId(int id){this.id=id;}
    public void   setName(String name){this.name=name;}
    public void   setPhone(int phone){this.phone=phone;}
    public void   setRoomNum(int roomNum){this.roomNum=roomNum;}
    public void   setLastName(String lastName){this.lastName=lastName;}
    public void   setNickName(String nickName){this.nickName=nickName;}
    public void   setAddress(String address){this.address=address;}

    public int    getId(){return id;}
    public int    getPhone(){return phone;}
    public String getName(){return name;}
    public String getAddress(){return address;}
    public String getLastName(){return  lastName;}
    public String getNickName() {return nickName;}
    public int    getRoomNum(){return roomNum;}
}
